<?php 
    const SERVERURL = "http://beachynic.260mb.net/";//http://localhost/ClinicaMed/
    const SERVERURL2 = "http://beachynic.260mb.net/";
    
    const COMPANY = "Beachy Nicaragua";

    const COMPANY_DIRECTION="Rivas-Nicaragua";
    const COMPANY_EMAIL="beachynica@gmail.com";
    const COMPANY_PHONE="78761201";

    const MONEDA = "$";
    date_default_timezone_set("America/Managua");