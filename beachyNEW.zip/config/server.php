<?php 

    const SERVER = "sql300.260mb.net";

    const DB = "n260m_34982725_beachybd";

    const USER = "n260m_34982725";

    const PASS = "11111111";

    const SGDB = "mysql:host=".SERVER.";dbname=".DB;

    const METHOD = "AES-256-CBC";
    const SECRET_KEY = 'thisissecret';//$LUIS@2021
    const SECRET_IV = '130800';