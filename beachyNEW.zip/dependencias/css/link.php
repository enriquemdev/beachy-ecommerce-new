
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<!-- <link href="form-validation.css" rel="stylesheet"> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


<!-- Sweet Alerts V8.13.0 CSS file -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>dependencias/css/sweetalert2.min.css">
<link rel="stylesheet" href="<?php echo SERVERURL; ?>style.css">

<!-- Sweet Alert V8.13.0 JS file-->
<script src="<?php echo SERVERURL; ?>dependencias/js/sweetalert2.min.js" ></script>
<script src="<?php echo SERVERURL; ?>scripts2.js" ></script>