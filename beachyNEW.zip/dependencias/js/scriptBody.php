<!-- <script src="beachy/dependencias/js/jquery-3.4.1.min.js"></script>
<script src="beachy/dependencias/js/alertas.js"></script> -->

<script src="<?php echo SERVERURL; ?>dependencias/js/jquery-3.4.1.min.js"></script>
<script src="<?php echo SERVERURL; ?>dependencias/js/popper.min.js"></script>
<script src="<?php echo SERVERURL; ?>dependencias/js/alertas.js"></script>
