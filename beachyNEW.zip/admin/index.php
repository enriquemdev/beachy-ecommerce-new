<?php
require_once "../config/app.php";
header("Location: ".SERVERURL."pages/admin/login.php");
exit();
?>
