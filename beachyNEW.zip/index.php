<?php
//require_once "pages/home.php";
header("Location: pages/home.php");
exit();
?>
