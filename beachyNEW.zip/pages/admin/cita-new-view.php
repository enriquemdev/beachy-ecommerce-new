<?php
require_once "top.php" ;
?>



<!-- Page header -->
        <?php 
            // require_once "./controladores/citaControlador.php";
            // $ins_item = new citaControlador();
            // $datos_item=$ins_item->datos_item1_controlador();
            // if($datos_item->rowCount()==1){
            //     $campos=$datos_item->fetch();
            // }
		?>
        <br>
        <br>
        <h2>BIENVENIDO AL SISTEMA ADMINISTRATIVO DE BEACHY E-COMMERCE</h2>


                <?php
require_once "bottom.php" ;
?>