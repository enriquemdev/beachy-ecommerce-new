<!--=============================================
	=            Include JavaScript files           =
	==============================================-->
	<!-- jQuery V3.4.1 -->
	<script src="<?php echo SERVERURL; ?>vistas/js/jquery-3.4.1.min.js" ></script>

	<!-- popper -->
	<script src="<?php echo SERVERURL; ?>vistas/js/popper.min.js" ></script>

	<!-- Bootstrap V4.3 -->
	<script src="<?php echo SERVERURL; ?>vistas/js/bootstrap.min.js" ></script>

	<!-- jQuery Custom Content Scroller V3.1.5 -->
	<script src="<?php echo SERVERURL; ?>vistas/js/jquery.mCustomScrollbar.concat.min.js" ></script>

	<!-- Bootstrap Material Design V4.0 -->
	<script src="<?php echo SERVERURL; ?>vistas/js/bootstrap-material-design.min.js" ></script>
	<script>$(document).ready(function() { $('body').bootstrapMaterialDesign(); });</script>

	<script src="<?php echo SERVERURL; ?>vistas/js/main.js" ></script>
	<script src="<?php echo SERVERURL; ?>vistas/js/alertas.js" ></script>
	<script src="<?php echo SERVERURL; ?>vistas/js/chart.js" ></script>
	<script src="<?php echo SERVERURL; ?>vistas/js/graficadr.js" ></script>


		<!-- Aqu[i toc[o luis-->
	<!-- Bootstrap core JavaScript-->
    <script src="<?php echo SERVERURL; ?>vistas/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo SERVERURL; ?>vistas/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo SERVERURL; ?>vistas/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="<?php echo SERVERURL; ?>vistas/vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo SERVERURL; ?>vistas/js/demo/chart-area-demo.js"></script>
    <script src="<?php echo SERVERURL; ?>vistas/js/demo/chart-pie-demo.js"></script>
	<script src="<?php echo SERVERURL; ?>vistas/js/check.js"></script>
	<!-- 04/06/22 selectpicker -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>



	<script src="<?php echo SERVERURL; ?>vistas/js/selectAuto.js"></script>

	

	<!-- 13/06/2022 multiAutoComplete -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/bootstrap-tokenfield.js"></script>

	<script src="<?php echo SERVERURL; ?>vistas/js/multiAutoComplete.js"></script>
	



