<!-- Normalize V8.0.1 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>pages/admin/css/normalize.css">

<!-- Bootstrap V4.3 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>pages/admin/css/bootstrap.min.css">

<!-- Bootstrap Material Design V4.0 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>pages/admin/css/bootstrap-material-design.min.css">

<!-- Font Awesome V5.9.0 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>pages/admin/css/all.css">
<!-- Font Awesome V5.9.0 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>pages/admin/css/fontawesome.min.css">


<!-- Sweet Alerts V8.13.0 CSS file -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>pages/admin/css/sweetalert2.min.css">

<!-- Sweet Alert V8.13.0 JS file-->
<script src="<?php echo SERVERURL; ?>pages/admin/js/sweetalert2.min.js" ></script>

<!-- jQuery Custom Content Scroller V3.1.5 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>pages/admin/css/jquery.mCustomScrollbar.css">

<!-- General Styles -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>pages/admin/css/style.css">

<!-- Estilos para los buscadores en los textbox -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>pages/admin/css/buscadorForm.css">

<!-- General Styles custom -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>pages/admin/css/styletable.css">

<!-- 04/06/22 selectpicker -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">

<!-- 13/06/2022 multiAutoComplete -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" /> -->
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/css/bootstrap-tokenfield.min.css">

<!-- DATATABLES -->
<link href="https://unpkg.com/vanilla-datatables@latest/dist/vanilla-dataTables.min.css" rel="stylesheet" type="text/css">
<script src="https://unpkg.com/vanilla-datatables@latest/dist/vanilla-dataTables.min.js" type="text/javascript"></script>

