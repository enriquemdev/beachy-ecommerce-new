<?php

$alerta=[
    "Alerta"=>"recargar",
    "Titulo"=>"Empleado registrado",
    "Texto"=>"Empleado registrado correctamente",
    "Tipo"=>"success"
];
echo json_encode($alerta);